import React, { createContext, useContext, useState } from 'react'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null) // { name, email, method: 'email' | 'google' }

  const login = (email) => {
    setUser({ name: email.split('@')[0], email, method: 'email' })
  }

  const signup = (name, email) => {
    setUser({ name, email, method: 'email' })
  }

  const loginWithGoogle = () => {
    // NOTE: This is a UI-only mock. Real "Continue with Google" requires
    // a backend + Google OAuth client ID (e.g. via Firebase Auth or
    // Google Identity Services). See README.md for how to wire it up.
    setUser({ name: 'Google User', email: 'user@gmail.com', method: 'google' })
  }

  const logout = () => setUser(null)

  return (
    <AuthContext.Provider
      value={{ user, isLoggedIn: !!user, login, signup, loginWithGoogle, logout }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
