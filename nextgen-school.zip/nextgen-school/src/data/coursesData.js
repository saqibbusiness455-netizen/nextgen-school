const coursesData = [
  {
    id: 'digital-marketing',
    title: 'Digital Marketing',
    tagline: 'Grow brands with data',
    description:
      'SEO, paid ads, social media strategy, and analytics — build campaigns that actually convert.',
    duration: '8 weeks',
    fee: 15000,
    icon: '📈',
    level: 'Beginner',
    rating: 4.8,
    students: 1240,
    highlights: [
      'SEO & keyword research',
      'Meta & Google Ads',
      'Analytics & reporting',
      'Live client campaign',
    ],
  },
  {
    id: 'web-development',
    title: 'Web Development',
    tagline: 'Build the modern web',
    description:
      'HTML, CSS, JavaScript, React and backend basics. Ship real, working websites from scratch.',
    duration: '12 weeks',
    fee: 20000,
    icon: '💻',
    level: 'Beginner to Advanced',
    rating: 4.9,
    students: 2310,
    highlights: [
      'HTML, CSS & JavaScript',
      'React with hooks & props',
      'REST APIs & databases',
      '3 portfolio-ready projects',
    ],
  },
  {
    id: 'graphic-designing',
    title: 'Graphic Designing',
    tagline: 'Design that speaks',
    description:
      'Typography, color theory, branding, and hands-on Photoshop / Illustrator workflows.',
    duration: '8 weeks',
    fee: 14000,
    icon: '🎨',
    level: 'Beginner',
    rating: 4.7,
    students: 980,
    highlights: [
      'Typography & color theory',
      'Photoshop & Illustrator',
      'Brand identity design',
      'Client-ready portfolio',
    ],
  },
  {
    id: 'prompt-engineering',
    title: 'Prompt Engineering',
    tagline: 'Direct AI with precision',
    description:
      'Learn to design prompts, build AI workflows, and get reliable output from modern LLMs.',
    duration: '6 weeks',
    fee: 18000,
    icon: '🤖',
    level: 'Intermediate',
    rating: 4.9,
    students: 640,
    highlights: [
      'Prompt design frameworks',
      'AI workflow automation',
      'Working with major LLM APIs',
      'Real-world AI projects',
    ],
  },
  {
    id: 'video-editing',
    title: 'Video Editing',
    tagline: 'Cut, color, tell stories',
    description:
      'Premiere Pro / DaVinci Resolve, pacing, color grading, and sound design for real projects.',
    duration: '8 weeks',
    fee: 16000,
    icon: '🎬',
    level: 'Beginner',
    rating: 4.8,
    students: 870,
    highlights: [
      'Premiere Pro & DaVinci Resolve',
      'Pacing & storytelling',
      'Color grading',
      'Sound design basics',
    ],
  },
]

export default coursesData
