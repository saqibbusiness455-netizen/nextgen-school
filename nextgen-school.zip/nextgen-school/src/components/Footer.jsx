import React from 'react'
import { Link } from 'react-router-dom'
import './Footer.css'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <p className="footer__logo">NextGen School</p>
          <p className="footer__tagline">
            Practical, project-based courses for the next generation of makers.
          </p>
          <a
            href="https://wa.me/923254383667"
            target="_blank"
            rel="noopener noreferrer"
            className="footer__whatsapp"
          >
            WhatsApp: 0325 4383667
          </a>
        </div>

        <div className="footer__col">
          <h4>Courses</h4>
          <a href="#courses">Digital Marketing</a>
          <a href="#courses">Web Development</a>
          <a href="#courses">Graphic Designing</a>
          <a href="#courses">Prompt Engineering</a>
          <a href="#courses">Video Editing</a>
        </div>

        <div className="footer__col">
          <h4>Company</h4>
          <a href="#top">Home</a>
          <a href="#why-us">Why Us</a>
          <a href="#reviews">Reviews</a>
          <a href="#faq">FAQ</a>
        </div>

        <div className="footer__col">
          <h4>Get started</h4>
          <Link to="/auth?mode=signup">Create account</Link>
          <Link to="/auth?mode=login">Log in</Link>
        </div>
      </div>

      <p className="footer__copyright">
        © {new Date().getFullYear()} NextGen School. All rights reserved.
      </p>
    </footer>
  )
}
