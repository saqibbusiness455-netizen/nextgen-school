import React from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './Testimonials.css'

const testimonials = [
  {
    name: 'Ayesha K.',
    course: 'Web Development',
    quote:
      'I went from knowing nothing about code to shipping my own React projects in three months. The mentors actually reviewed my work line by line.',
  },
  {
    name: 'Hamza R.',
    course: 'Digital Marketing',
    quote:
      'The live campaign project was the best part — running a real ad budget and seeing actual results taught me more than any textbook could.',
  },
  {
    name: 'Sana M.',
    course: 'Graphic Designing',
    quote:
      'My portfolio finally looks professional. I started freelancing before I even finished the course.',
  },
  {
    name: 'Bilal A.',
    course: 'Prompt Engineering',
    quote:
      'Short course, huge impact. I now automate half my old job with the workflows I built here.',
  },
]

export default function Testimonials() {
  const [ref, inView] = useScrollReveal()

  return (
    <section id="reviews" ref={ref} className={`testimonials reveal ${inView ? 'in-view' : ''}`}>
      <div className="container">
        <h2 className="section-title">What students say</h2>
        <p className="section-subtitle">Real feedback from people who finished the course.</p>

        <div className="testimonials__grid">
          {testimonials.map((t) => (
            <blockquote key={t.name} className="testimonial-card">
              <p className="testimonial-card__quote">"{t.quote}"</p>
              <footer className="testimonial-card__footer">
                <span className="testimonial-card__avatar">{t.name.charAt(0)}</span>
                <div>
                  <cite className="testimonial-card__name">{t.name}</cite>
                  <p className="testimonial-card__course">{t.course}</p>
                </div>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  )
}
