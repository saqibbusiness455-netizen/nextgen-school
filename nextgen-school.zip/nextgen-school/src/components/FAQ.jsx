import React, { useState } from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './FAQ.css'

const faqs = [
  {
    q: 'Do I need any prior experience to join?',
    a: 'No. Most of our courses (Digital Marketing, Graphic Designing, Video Editing, Web Development) start from the basics. Prompt Engineering assumes basic computer comfort but no coding background.',
  },
  {
    q: 'Are classes live or recorded?',
    a: 'A mix of both — live sessions for direct interaction with mentors, plus recordings you can revisit anytime with lifetime access.',
  },
  {
    q: 'How do I pay the course fee?',
    a: 'Once you sign up and enroll in a course, you\'ll be taken to a secure payment page where you can pay the full fee by card.',
  },
  {
    q: 'Can I switch courses after enrolling?',
    a: 'Yes — message us on WhatsApp within the first week and we\'ll help you switch to a different course at no extra cost.',
  },
  {
    q: 'Do you offer a certificate?',
    a: 'Yes, every course ends with a shareable certificate once you submit your final project.',
  },
]

export default function FAQ() {
  const [ref, inView] = useScrollReveal()
  const [openIndex, setOpenIndex] = useState(0)

  return (
    <section id="faq" ref={ref} className={`faq reveal ${inView ? 'in-view' : ''}`}>
      <div className="container faq__container">
        <h2 className="section-title">Frequently asked questions</h2>

        <div className="faq__list">
          {faqs.map((item, i) => (
            <div key={item.q} className={`faq__item ${openIndex === i ? 'is-open' : ''}`}>
              <button
                className="faq__question"
                onClick={() => setOpenIndex(openIndex === i ? -1 : i)}
                aria-expanded={openIndex === i}
              >
                {item.q}
                <span className="faq__icon">{openIndex === i ? '−' : '+'}</span>
              </button>
              <div className="faq__answer">
                <p>{item.a}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
