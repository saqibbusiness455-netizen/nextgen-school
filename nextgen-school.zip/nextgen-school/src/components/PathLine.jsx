import React from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './PathLine.css'

/**
 * A glowing vertical line that "draws itself" as the courses section
 * scrolls into view — represents the learning path through NextGen School.
 */
export default function PathLine() {
  const [ref, inView] = useScrollReveal(0.1)

  return (
    <div ref={ref} className="path-line">
      <svg
        className={`path-line__svg ${inView ? 'is-drawn' : ''}`}
        viewBox="0 0 4 600"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <line x1="2" y1="0" x2="2" y2="600" />
      </svg>
    </div>
  )
}
