import React from 'react'
import { useNavigate } from 'react-router-dom'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './CTASection.css'

export default function CTASection() {
  const [ref, inView] = useScrollReveal()
  const navigate = useNavigate()

  return (
    <section ref={ref} className={`cta reveal ${inView ? 'in-view' : ''}`}>
      <div className="container cta__inner">
        <h2>Ready to start learning?</h2>
        <p>Pick a course, create your account, and start building from day one.</p>
        <div className="cta__actions">
          <a href="#courses" className="btn btn--solid">Browse Courses</a>
          <a
            href="https://wa.me/923254383667"
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn--ghost"
          >
            Chat on WhatsApp
          </a>
        </div>
      </div>
    </section>
  )
}
