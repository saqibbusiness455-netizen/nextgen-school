import React, { useEffect, useState } from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './StatsBar.css'

const stats = [
  { label: 'Students Trained', value: 6200, suffix: '+' },
  { label: 'Courses', value: 5, suffix: '' },
  { label: 'Avg. Rating', value: 4.8, suffix: '/5', decimals: 1 },
  { label: 'Job-Ready Graduates', value: 92, suffix: '%' },
]

function Counter({ value, suffix, decimals = 0, active }) {
  const [display, setDisplay] = useState(0)

  useEffect(() => {
    if (!active) return
    const duration = 1200
    const start = performance.now()

    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1)
      setDisplay(value * progress)
      if (progress < 1) requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  }, [active, value])

  return (
    <span className="stat-card__value">
      {display.toFixed(decimals)}
      {suffix}
    </span>
  )
}

export default function StatsBar() {
  const [ref, inView] = useScrollReveal(0.3)

  return (
    <section ref={ref} className={`stats-bar reveal ${inView ? 'in-view' : ''}`}>
      <div className="container stats-bar__grid">
        {stats.map((s) => (
          <div key={s.label} className="stat-card">
            <Counter value={s.value} suffix={s.suffix} decimals={s.decimals} active={inView} />
            <span className="stat-card__label">{s.label}</span>
          </div>
        ))}
      </div>
    </section>
  )
}
