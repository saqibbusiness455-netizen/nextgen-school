import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import './Navbar.css'

const WHATSAPP_NUMBER = '923254383667' // 0325 4383667 in international format

export default function Navbar() {
  const navigate = useNavigate()
  const { isLoggedIn, user, logout } = useAuth()
  const [open, setOpen] = useState(false)

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <a href="#top" className="navbar__logo">
          Next<span>Gen</span> School
        </a>

        <nav className={`navbar__links ${open ? 'is-open' : ''}`}>
          <a href="#top" onClick={() => setOpen(false)}>Home</a>
          <a href="#courses" onClick={() => setOpen(false)}>Courses</a>
          <a href="#why-us" onClick={() => setOpen(false)}>Why Us</a>
          <a href="#reviews" onClick={() => setOpen(false)}>Reviews</a>
          <a href="#faq" onClick={() => setOpen(false)}>FAQ</a>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="navbar__whatsapp"
          >
            WhatsApp: 0325 4383667
          </a>
        </nav>

        <div className="navbar__actions">
          {isLoggedIn ? (
            <>
              <span className="navbar__user">Hi, {user.name}</span>
              <button className="btn btn--ghost" onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <button className="btn btn--ghost" onClick={() => navigate('/auth?mode=login')}>
                Login
              </button>
              <button className="btn btn--solid" onClick={() => navigate('/auth?mode=signup')}>
                Sign Up
              </button>
            </>
          )}
        </div>

        <button
          className="navbar__burger"
          aria-label="Toggle menu"
          onClick={() => setOpen((o) => !o)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  )
}
