import React from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './CourseCard.css'

/**
 * Presentational card driven entirely by props.
 * course: { id, title, tagline, description, duration, fee, icon }
 * onEnroll: (course) => void
 */
export default function CourseCard({ course, onEnroll }) {
  const [ref, inView] = useScrollReveal()

  return (
    <article ref={ref} className={`course-card reveal ${inView ? 'in-view' : ''}`}>
      <div className="course-card__top">
        <div className="course-card__icon">{course.icon}</div>
        <span className="course-card__level">{course.level}</span>
      </div>

      <h3 className="course-card__title">{course.title}</h3>
      <p className="course-card__tagline">{course.tagline}</p>
      <p className="course-card__desc">{course.description}</p>

      <ul className="course-card__highlights">
        {course.highlights.map((point) => (
          <li key={point}>{point}</li>
        ))}
      </ul>

      <div className="course-card__stats">
        <span className="course-card__rating">★ {course.rating}</span>
        <span className="course-card__students">{course.students.toLocaleString()} students</span>
      </div>

      <div className="course-card__meta">
        <span>{course.duration}</span>
        <span className="course-card__fee">Rs. {course.fee.toLocaleString()}</span>
      </div>

      <button className="course-card__cta" onClick={() => onEnroll(course)}>
        Enroll Now →
      </button>
    </article>
  )
}
