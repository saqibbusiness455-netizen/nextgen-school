import React from 'react'
import useScrollReveal from '../hooks/useScrollReveal.js'
import './WhyUs.css'

const features = [
  {
    icon: '🎯',
    title: 'Project-based learning',
    desc: 'Every course ends with real, portfolio-ready projects — not just quizzes.',
  },
  {
    icon: '🧑‍🏫',
    title: 'Industry mentors',
    desc: 'Learn from people who work in the field, not just teach theory.',
  },
  {
    icon: '💬',
    title: '1-on-1 doubt support',
    desc: 'Stuck on something? Get direct help over WhatsApp, not a ticket queue.',
  },
  {
    icon: '📜',
    title: 'Certificate on completion',
    desc: 'A shareable certificate the moment you finish your final project.',
  },
  {
    icon: '💼',
    title: 'Career guidance',
    desc: 'Resume reviews, portfolio feedback, and interview prep included.',
  },
  {
    icon: '🔁',
    title: 'Lifetime access',
    desc: 'Revisit course material anytime — recordings never expire.',
  },
]

export default function WhyUs() {
  const [ref, inView] = useScrollReveal()

  return (
    <section id="why-us" ref={ref} className={`why-us reveal ${inView ? 'in-view' : ''}`}>
      <div className="container">
        <h2 className="section-title">Why learn at NextGen School</h2>
        <p className="section-subtitle">Built for people who want to actually build things.</p>

        <div className="why-us__grid">
          {features.map((f) => (
            <div key={f.title} className="why-us__card">
              <span className="why-us__icon">{f.icon}</span>
              <h3>{f.title}</h3>
              <p>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
