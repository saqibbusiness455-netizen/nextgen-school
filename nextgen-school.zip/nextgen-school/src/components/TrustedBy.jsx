import React from 'react'
import './TrustedBy.css'

const tags = [
  'SEO', 'React', 'Google Ads', 'Photoshop', 'Prompt Engineering', 'Illustrator',
  'Premiere Pro', 'Node.js', 'Meta Ads', 'DaVinci Resolve', 'Analytics', 'JavaScript',
]

export default function TrustedBy() {
  const loop = [...tags, ...tags]

  return (
    <section className="trusted-by">
      <p className="trusted-by__label">Skills our graduates get hired for</p>
      <div className="trusted-by__track">
        <div className="trusted-by__marquee">
          {loop.map((tag, i) => (
            <span key={i} className="trusted-by__tag">{tag}</span>
          ))}
        </div>
      </div>
    </section>
  )
}
