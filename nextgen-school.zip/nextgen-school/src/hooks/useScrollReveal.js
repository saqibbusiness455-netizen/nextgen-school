import { useEffect, useRef, useState } from 'react'

/**
 * Returns a ref to attach to any element, and a boolean that becomes
 * true once that element scrolls into view. Combine with the global
 * `.reveal` / `.in-view` CSS classes for fade-up scroll animations.
 */
export default function useScrollReveal(threshold = 0.15) {
  const ref = useRef(null)
  const [inView, setInView] = useState(false)

  useEffect(() => {
    const node = ref.current
    if (!node) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          observer.disconnect() // animate once
        }
      },
      { threshold }
    )

    observer.observe(node)
    return () => observer.disconnect()
  }, [threshold])

  return [ref, inView]
}
