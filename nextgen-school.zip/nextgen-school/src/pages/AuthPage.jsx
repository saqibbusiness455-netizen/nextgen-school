import React, { useState } from 'react'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import './AuthPage.css'

export default function AuthPage() {
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const location = useLocation()
  const { login, signup, loginWithGoogle } = useAuth()

  const [mode, setMode] = useState(params.get('mode') === 'login' ? 'login' : 'signup')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  // If the user was sent here after clicking "Enroll" on a course, we
  // carry that course through so payment can pick it up post-login.
  const pendingCourse = location.state?.course

  const goAfterAuth = () => {
    if (pendingCourse) {
      navigate('/payment', { state: { course: pendingCourse } })
    } else {
      navigate('/')
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (mode === 'signup') {
      signup(name || 'Student', email)
    } else {
      login(email)
    }
    goAfterAuth()
  }

  const handleGoogle = () => {
    loginWithGoogle()
    goAfterAuth()
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <button className="auth-card__skip" onClick={() => navigate('/')}>
          ← Back to home
        </button>

        <h1 className="auth-card__title">
          {mode === 'signup' ? 'Create your account' : 'Welcome back'}
        </h1>
        <p className="auth-card__subtitle">
          {pendingCourse
            ? `Sign in to enroll in ${pendingCourse.title}`
            : 'Access your NextGen School dashboard'}
        </p>

        <div className="auth-tabs">
          <button
            className={mode === 'login' ? 'is-active' : ''}
            onClick={() => setMode('login')}
          >
            Login
          </button>
          <button
            className={mode === 'signup' ? 'is-active' : ''}
            onClick={() => setMode('signup')}
          >
            Sign Up
          </button>
        </div>

        <button className="google-btn" onClick={handleGoogle} type="button">
          <span className="google-btn__icon">G</span>
          Continue with Google
        </button>

        <div className="auth-divider"><span>or</span></div>

        <form onSubmit={handleSubmit} className="auth-form">
          {mode === 'signup' && (
            <label>
              Full name
              <input value={name} onChange={(e) => setName(e.target.value)} required />
            </label>
          )}
          <label>
            Email
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
          </label>

          <button type="submit" className="btn btn--solid auth-form__submit">
            {mode === 'signup' ? 'Create account' : 'Log in'}
          </button>
        </form>

        <button className="auth-card__later" onClick={() => navigate('/')}>
          Maybe later, just let me browse
        </button>
      </div>
    </div>
  )
}
