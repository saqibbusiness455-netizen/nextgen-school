import React from 'react'
import { useNavigate } from 'react-router-dom'
import Navbar from '../components/Navbar.jsx'
import Footer from '../components/Footer.jsx'
import CourseCard from '../components/CourseCard.jsx'
import PathLine from '../components/PathLine.jsx'
import StatsBar from '../components/StatsBar.jsx'
import TrustedBy from '../components/TrustedBy.jsx'
import WhyUs from '../components/WhyUs.jsx'
import Testimonials from '../components/Testimonials.jsx'
import FAQ from '../components/FAQ.jsx'
import CTASection from '../components/CTASection.jsx'
import useScrollReveal from '../hooks/useScrollReveal.js'
import { useAuth } from '../context/AuthContext.jsx'
import coursesData from '../data/coursesData.js'
import './Landing.css'

export default function Landing() {
  const navigate = useNavigate()
  const { isLoggedIn } = useAuth()
  const [heroRef, heroIn] = useScrollReveal(0)
  const [aboutRef, aboutIn] = useScrollReveal()

  // Clicking "Enroll" gates the user behind auth, unless already logged in.
  const handleEnroll = (course) => {
    if (isLoggedIn) {
      navigate('/payment', { state: { course } })
    } else {
      navigate('/auth?mode=signup', { state: { course } })
    }
  }

  return (
    <div id="top">
      <Navbar />

      {/* HERO */}
      <section ref={heroRef} className={`hero reveal ${heroIn ? 'in-view' : ''}`}>
        <div className="hero__glow" />
        <div className="container hero__inner">
          <p className="hero__eyebrow">NextGen School</p>
          <h1 className="hero__title">
            Learn the skills <span>the next generation</span> actually needs.
          </h1>
          <p className="hero__subtitle">
            Five practical, project-based courses — Digital Marketing, Web Development,
            Graphic Designing, Prompt Engineering, and Video Editing. Taught for people who
            want to build real things, not just watch lectures.
          </p>
          <div className="hero__actions">
            <a href="#courses" className="btn btn--solid">Explore Courses</a>
            <a href="#why-us" className="btn btn--ghost">Why NextGen</a>
          </div>
        </div>
      </section>

      <StatsBar />
      <TrustedBy />

      {/* ABOUT / INTRO */}
      <section id="about" ref={aboutRef} className={`about reveal ${aboutIn ? 'in-view' : ''}`}>
        <div className="container">
          <h2 className="section-title">What you'll find on this site</h2>
          <div className="about__grid">
            <div className="about__item">
              <h3>Five focused courses</h3>
              <p>Pick one skill and go deep — each course is built around real projects, not filler.</p>
            </div>
            <div className="about__item">
              <h3>Clear pricing</h3>
              <p>Every course shows its fee upfront. No hidden costs, pay securely when you enroll.</p>
            </div>
            <div className="about__item">
              <h3>Fast sign-in</h3>
              <p>Browse freely without an account. Sign up only when you're ready to enroll.</p>
            </div>
          </div>
        </div>
      </section>

      {/* COURSES */}
      <section id="courses" className="courses">
        <div className="container courses__container">
          <h2 className="section-title">Choose your course</h2>
          <p className="section-subtitle">Every path below leads somewhere real.</p>

          <div className="courses__grid">
            <PathLine />
            {coursesData.map((course) => (
              <CourseCard key={course.id} course={course} onEnroll={handleEnroll} />
            ))}
          </div>
        </div>
      </section>

      <WhyUs />
      <Testimonials />
      <FAQ />
      <CTASection />

      <Footer />
    </div>
  )
}
