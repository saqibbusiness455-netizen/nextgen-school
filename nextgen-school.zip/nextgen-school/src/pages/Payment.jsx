import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import './Payment.css'

export default function Payment() {
  const location = useLocation()
  const navigate = useNavigate()
  const { isLoggedIn } = useAuth()
  const course = location.state?.course

  const [cardName, setCardName] = useState('')
  const [cardNumber, setCardNumber] = useState('')
  const [expiry, setExpiry] = useState('')
  const [cvv, setCvv] = useState('')
  const [success, setSuccess] = useState(false)

  // No course selected or not logged in — nothing to pay for, send back.
  if (!course) {
    return (
      <div className="payment-empty">
        <p>No course selected yet.</p>
        <button className="btn btn--solid" onClick={() => navigate('/')}>
          Browse courses
        </button>
      </div>
    )
  }

  if (!isLoggedIn) {
    navigate('/auth?mode=login', { state: { course } })
    return null
  }

  const formatCardNumber = (value) =>
    value
      .replace(/\D/g, '')
      .slice(0, 16)
      .replace(/(.{4})/g, '$1 ')
      .trim()

  const handlePay = (e) => {
    e.preventDefault()
    // This is a UI-only demo. A real integration would call a payment
    // processor (Stripe, JazzCash, Easypaisa, etc.) from a secure backend —
    // card details should never be sent to your own server directly.
    setSuccess(true)
  }

  if (success) {
    return (
      <div className="payment-success">
        <div className="payment-success__check">✓</div>
        <h1>Payment successful</h1>
        <p>
          You're enrolled in <strong>{course.title}</strong>. A confirmation will be sent to
          your email shortly.
        </p>
        <button className="btn btn--solid" onClick={() => navigate('/')}>
          Back to home
        </button>
      </div>
    )
  }

  return (
    <div className="payment-page">
      <div className="payment-card">
        <button className="payment-card__back" onClick={() => navigate('/')}>
          ← Back
        </button>

        <div className="payment-summary">
          <span className="payment-summary__icon">{course.icon}</span>
          <div>
            <h2>{course.title}</h2>
            <p>{course.duration} · Rs. {course.fee.toLocaleString()}</p>
          </div>
        </div>

        <form onSubmit={handlePay} className="payment-form">
          <label>
            Name on card
            <input value={cardName} onChange={(e) => setCardName(e.target.value)} required />
          </label>
          <label>
            Card number
            <input
              value={cardNumber}
              onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
              placeholder="1234 5678 9012 3456"
              inputMode="numeric"
              required
            />
          </label>
          <div className="payment-form__row">
            <label>
              Expiry
              <input
                value={expiry}
                onChange={(e) => setExpiry(e.target.value)}
                placeholder="MM/YY"
                required
              />
            </label>
            <label>
              CVV
              <input
                value={cvv}
                onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                placeholder="123"
                inputMode="numeric"
                required
              />
            </label>
          </div>

          <button type="submit" className="btn btn--solid payment-form__submit">
            Pay Rs. {course.fee.toLocaleString()}
          </button>
          <p className="payment-form__note">
            Demo form — no real payment is processed.
          </p>
        </form>
      </div>
    </div>
  )
}
