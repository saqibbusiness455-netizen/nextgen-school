# NextGen School

React + Vite website for NextGen School — dark black & blue theme, 5 courses
(Digital Marketing, Web Development, Graphic Designing, Prompt Engineering,
Video Editing), landing page with scroll animations, a login/signup flow
gated behind course enrollment, and a demo card-payment page.

## Run it locally

You need [Node.js](https://nodejs.org) (v18+) installed.

```bash
cd nextgen-school
npm install
npm run dev
```

Then open the URL shown in the terminal (usually `http://localhost:5173`).

## Project structure

```
src/
  main.jsx                 → app entry point
  App.jsx                  → routes ("/", "/auth", "/payment")
  index.css                → design tokens (colors, fonts) + global styles
  context/AuthContext.jsx   → login/signup/Google state (in-memory only)
  data/coursesData.js       → the 5 courses, edit fees/text here
  hooks/useScrollReveal.js  → scroll-triggered fade-up animation hook
  components/
    Navbar.jsx / .css       → top nav, login/signup buttons, WhatsApp link
    Footer.jsx / .css       → multi-column footer with WhatsApp contact
    CourseCard.jsx / .css   → reusable course card (driven by props)
    PathLine.jsx / .css     → signature glowing scroll-drawn line
    StatsBar.jsx / .css     → animated counters (students, rating, etc.)
    TrustedBy.jsx / .css    → scrolling marquee of skills/tech taught
    WhyUs.jsx / .css        → feature grid (mentors, certificates, etc.)
    Testimonials.jsx / .css → student review cards
    FAQ.jsx / .css          → accordion of common questions
    CTASection.jsx / .css   → final call-to-action before the footer
  pages/
    Landing.jsx / .css      → hero, intro, courses grid
    AuthPage.jsx / .css     → login/signup tabs + "Continue with Google"
    Payment.jsx / .css      → card form for the selected course
```

## How the flow works

1. **Landing page** loads directly — no login wall, anyone can browse.
2. Clicking **"Enroll Now"** on a course sends logged-out users to `/auth`
   (their chosen course is carried along in route state).
3. On `/auth` they can **log in**, **sign up**, or **Continue with Google**.
   There's also a **"Maybe later, just let me browse"** link and a
   **"← Back to home"** button to skip and return to the landing page
   without creating an account.
4. After auth, they land on `/payment` with their chosen course pre-filled,
   fill in demo card details, and see a success screen.

## Important — things that need real backend work

This is a front-end-only build, as requested, so a couple of pieces are
UI mocks that will need a backend before going live:

- **"Continue with Google"** — currently just sets a fake logged-in user
  in `AuthContext.jsx`. For real Google sign-in you'd add Firebase Auth or
  Google Identity Services with a real OAuth client ID.
- **Login / Sign up** — currently stores the user in memory only (it
  resets on page refresh). A real version needs a backend (e.g. Node +
  a database) to store accounts and passwords securely — never store
  plain-text passwords in the frontend.
- **Payment** — the card form on `/payment` is a visual demo and does
  **not** process real payments. For real payments in Pakistan you'd
  typically integrate **JazzCash**, **Easypaisa**, or **Stripe**
  through a secure backend endpoint — card numbers should never be sent
  directly from the browser to your own server.

## Editing content

- Courses & fees: `src/data/coursesData.js`
- WhatsApp number: search for `923254383667` in `Navbar.jsx` and
  `Footer.jsx` (already set to 0325 4383667)
- Colors/fonts: `:root` variables at the top of `src/index.css`
